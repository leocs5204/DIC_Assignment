# environment is using pytorch under conda 

execute python file through conda

The image is loaded from and saved in location ./images/ 
please put the hidden test data image in the folder ./images/

# execute the code 
run "python atconv.py"